Got the wheel to work with modifications towards the solar system
"Don't reinvent the wheel." Am I right?

Using the gl.slideshow library kinda asks what teh assignments is for but with bad options for images.
Although this does show that there is something moving on the screen I couldn't figure out how to overlap them
or to get one on top of the other. This does show I kinda get it at least.

I thought of a way we could do it with a VERY large cylinder that would rotaet about an axis in the field of vision
the user would be looking into the cylinder as this cylinder would be larger than the viewing frustum.
An inside out look if you will. But this didn't come to fruition.

Tried to amke an attempt for a cylinder but it didn't work as intended so I scrapped that idea.
included that in the zip folder as well.

All the other common files are accessable in common so I did not provide them.
