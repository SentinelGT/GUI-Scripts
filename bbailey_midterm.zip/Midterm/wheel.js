/////////////////////////////////////////////////////////////////////////////
//
//  No need to reinvent the 'wheel'
//
/////////////////////////////////////////////////////////////////////////////

var canvas;
var gl;


//drawing the wheel

var wheelParts = {
  middleWheel : undefined,
  spokeOneOne : undefined,
  spokeOneTwo : undefined,
  spokeOneThree : undefined,
  spokeTwoOne : undefined,
  spokeTwoTwo : undefined,
  spokeTwoThree : undefined,
  spokeThreeOne : undefined,
  spokeThreeTwo : undefined,
  spokeThreeThree : undefined,
  spokeFourOne : undefined,
  spokeFourTwo : undefined,
  spokeFourThree : undefined,
  wheelOne : undefined,
  wheelTwo : undefined,
  wheelThree : undefined,
  wheelFour : undefined,
  wheelFive : undefined,
  wheelSix : undefined,
  wheelSeven : undefined,
  wheelEight : undefined,
  wheelNine : undefined,
  wheelTen : undefined,
  wheelEleven : undefined,
  wheelTwelve : undefined,
  wheelThirteen : undefined,
  wheelFourteen : undefined,
  wheelFifteen : undefined,
  wheelSixteen : undefined,
  wheelSeventeen : undefined,
  wheelEighteen : undefined,
  wheelNineteen : undefined,
  wheelTwenty : undefined,  
  
};


// we know what this does already
var V; 
var P;  
var near = 10;      
var far = 120;      

// Animation variables
var time = 0.0;      // time, our global time constant, which is 
                     // incremented every frame
var timeDelta = 0.5; // the amount that time is updated each fraime


//---------------------------------------------------------------------------
//
//  init() - scene initialization function
//

function init() {
  canvas = document.getElementById("webgl-canvas");

  // Configure our WebGL environment
  gl = WebGLUtils.setupWebGL(canvas);
  if (!gl) { alert("WebGL initialization failed"); }

  //color scale to simulate colors, or time of day



  gl.clearColor(0.0, 0.0, 0.0, 0.0);
  
  gl.enable(gl.DEPTH_TEST);
  

  for (var name in wheelParts ) {

    // if you need to know how this part works please look at the solar system
    // did not use the previous function from solars system as it wasn't very scalable
    // moon position and more planets might have caused problems.
    var wheelPart = wheelParts[name] = new Sphere();


    wheelPart.uniforms = { 
      color : gl.getUniformLocation(wheelPart.program, "color"),
      MV : gl.getUniformLocation(wheelPart.program, "MV"),
      P : gl.getUniformLocation(wheelPart.program, "P"),
    };
  }

  resize();

  window.requestAnimationFrame(render);  
}

//---------------------------------------------------------------------------
//
//  render() - render the scene
//  This 'wheel' will have a bunch of other smaller spheres to render itself

function render() {
  time += timeDelta;

  var ms = new MatrixStack();



  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);


  V = translate(0.0, 0.0, -0.5*(near + far));
  ms.load(V);  

  //using matrix stack to draw and render wheel parts and spokes

  var name, wheelPart, data;
   
  name = "middleWheel";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];
  
  

  wheelPart.PointMode = false; 
  


  ms.push();
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  
  name = "spokeOneOne";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance , 0, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  
  name = "spokeOneTwo";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance , 0, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  
  Ename = "spokeOneThree";
  EwheelPart = wheelParts[Ename];
  Edata = WheelSystems[Ename];

  EwheelPart.PointMode = false;

  ms.push();
  ms.rotate(Edata.year * time, Edata.axis);
  ms.translate(Edata.distance , 0, 0);
  ms.scale(Edata.radius);
  gl.useProgram(EwheelPart.program);
  gl.uniformMatrix4fv(EwheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(EwheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(EwheelPart.uniforms.color, flatten(Edata.color));
  EwheelPart.render();
  ms.pop();
  
  
  name = "spokeTwoOne";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(-data.distance , 0, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  
  name = "spokeTwoTwo";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

 ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(-data.distance , 0, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
 
  name = "spokeTwoThree";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(-data.distance , 0, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  

  
  
  name = "spokeThreeOne";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;
  
  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance - 7.5, 4.5,  0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();

  name = "spokeThreeTwo";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;
  
  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance - 4, 8,  0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
    
  name = "spokeThreeThree";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance - 10.5, 11,  0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "spokeFourOne";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;
  
  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance - 7.5, -4.5,  0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "spokeFourTwo";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;
  
  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance - 3.5, -8,  0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();

  name = "spokeFourThree";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance - 10.5, -11, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelOne";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance - 8, -11, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelTwo";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance - 11.5, -10, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelThree";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance - 13, -9, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelThree";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance - 14, -6.5, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelFour";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance - 15, -4, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelFive";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance - 15, -4, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelSix";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance + 0.5, 11, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelSeven";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance + 3.5, 9, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelEight";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance + 5.5, 7.5, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelNine";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance + 7, 5.5, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelTen";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance + 8, 3, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
    name = "wheelEleven";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance + 7, -4, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelTwelve";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance + 6, -6, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelThirteen";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance + 4.5, -7.5, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelFourteen";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance + 2, -10, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelFifteen";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance , -11, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
    name = "wheelSixteen";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance - 16, 3, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelSeventeen";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance - 14, 6, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelEighteen";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance - 12, 7.5, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelNineteen";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance - 10, 9, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  
  name = "wheelTwenty";
  wheelPart = wheelParts[name];
  data = WheelSystems[name];

  wheelPart.PointMode = false;

  ms.push();
  ms.rotate(data.year * time, data.axis);
  ms.translate(data.distance - 7, 11, 0);
  ms.scale(data.radius);
  gl.useProgram(wheelPart.program);
  gl.uniformMatrix4fv(wheelPart.uniforms.MV, false, flatten(ms.current()));
  gl.uniformMatrix4fv(wheelPart.uniforms.P, false, flatten(P));
  gl.uniform4fv(wheelPart.uniforms.color, flatten(data.color));
  wheelPart.render();
  ms.pop();
  window.requestAnimationFrame(render);
}

//---------------------------------------------------------------------------
//
//  resize() - handle resize events
//

function resize() {
  var w = canvas.clientWidth;
  var h = canvas.clientHeight;

  gl.viewport(0, 0, w, h);

  var fovy = 50.0; // for more of a top down view
  var aspect = w / h;

  P = perspective(fovy, aspect, near, far);
}

//---------------------------------------------------------------------------
//
//  Window callbacks for processing various events
//

window.onload = init;
window.onresize = resize;